/// Parámetros comerciales para /mundicam/v1/catalog-filters.
///
/// No contiene tokens: la autenticación se mantiene en ApiService._appOptions.
/// En producción, R19 opt-in permanece DESACTIVADO hasta QA en WordPress.
class CatalogFilterRequest {
  const CatalogFilterRequest._();

  static Map<String, dynamic> params({
    required int categoryId,
    int? brandId,
    String? search,
    bool fastFacetsOnly = false,
  }) {
    final cleanedSearch = search?.trim() ?? '';
    return <String, dynamic>{
      'category_id': categoryId,
      'include_subcategories': 1,
      if (brandId != null && brandId > 0) 'brand_id': brandId,
      if (brandId != null && brandId > 0) 'brandId': brandId,
      if (cleanedSearch.isNotEmpty) 'search': cleanedSearch,
      if (fastFacetsOnly) 'facets_only': 1,
    };
  }
}
