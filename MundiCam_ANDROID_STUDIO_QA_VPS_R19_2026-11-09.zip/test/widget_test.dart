import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mundicam/features/home/presentation/widgets/search_bar.dart';

void main() {
  testWidgets('MundiCam inicia con buscador visible sin consultar la red', (
    WidgetTester tester,
  ) async {
    // Sustituye el test de contador que Flutter crea por defecto.
    // MundiCam no tiene contador; el buscador real sí debe abrir sin red.
    await tester.pumpWidget(
      const MaterialApp(home: Scaffold(body: SearchBarWidget())),
    );
    expect(find.byType(SearchBarWidget), findsOneWidget);
    expect(
      find.widgetWithText(
        TextField,
        'Buscar por producto, marca, tecnología...',
      ),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });
}
