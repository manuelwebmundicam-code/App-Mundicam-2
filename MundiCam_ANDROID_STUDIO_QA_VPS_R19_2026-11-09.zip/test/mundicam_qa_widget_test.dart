import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mundicam/main_qa.dart' show MundiCamQaApp;

void main() {
  testWidgets('Android QA muestra solo entorno local sin pagos ni producción', (
    tester,
  ) async {
    await tester.pumpWidget(const MundiCamQaApp());
    expect(find.textContaining('PRUEBAS AISLADAS'), findsOneWidget);
    expect(find.textContaining('127.0.0.1:8770'), findsOneWidget);
    expect(find.byKey(const Key('qa_status_button')), findsOneWidget);
    expect(find.byKey(const Key('qa_login_button')), findsOneWidget);
    expect(find.textContaining('Realizar pedido'), findsNothing);
    expect(tester.takeException(), isNull);
  });
}
