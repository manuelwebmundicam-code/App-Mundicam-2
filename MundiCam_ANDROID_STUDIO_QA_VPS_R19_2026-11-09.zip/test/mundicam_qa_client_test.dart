import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mundicam/qa/mundicam_qa_client.dart';

Dio qaFakeDio({String version = '1.9.64-r19-facets-only-optin'}) {
  final dio = Dio(BaseOptions(baseUrl: MundicamQaClient.baseUrl));
  dio.interceptors.add(
    InterceptorsWrapper(
      onRequest: (request, handler) {
        final path = request.path;
        dynamic body;
        if (path.endsWith('/status')) {
          body = {'version': version, 'success': true};
        } else if (path.endsWith('/login')) {
          body = {'app_token': 'token-ficticio-qa', 'success': true};
        } else if (path.endsWith('/me')) {
          if (request.headers['X-MundiCam-App-Token'] != 'token-ficticio-qa') {
            return handler.reject(
              DioException(
                requestOptions: request,
                response: Response(requestOptions: request, statusCode: 401),
              ),
            );
          }
          body = {
            'success': true,
            'user': {
              'roles': ['qa_comercial'],
            },
          };
        } else if (path.endsWith('/catalog-filters')) {
          final fast =
              request.queryParameters['facets_only']?.toString() == '1';
          body = {
            'total_products': 1,
            'price_range': fast ? null : {'min': 10.00, 'max': 10.00},
            'stock_filter': fast ? null : {'in_stock': 1},
            'filters': [
              {
                'taxonomy': 'pa_tipo',
                'options': [
                  {'id': 22, 'slug': 'domo', 'count': 1},
                ],
              },
            ],
          };
        } else if (path.endsWith('/products')) {
          if (request.queryParameters['orderby'] != 'price_asc') {
            throw StateError('La QA ha cambiado la ordenación comercial.');
          }
          body = {
            'success': true,
            'products': [
              {'id': 101, 'price': '7.00'},
            ],
          };
        } else {
          return handler.reject(DioException(requestOptions: request));
        }
        return handler.resolve(
          Response<Map<String, dynamic>>(
            requestOptions: request,
            statusCode: 200,
            data: Map<String, dynamic>.from(body as Map),
          ),
        );
      },
    ),
  );
  return dio;
}

void main() {
  test(
    'el QA no comparte sesión y valida R19 antes de iniciar pruebas',
    () async {
      final client = MundicamQaClient(dio: qaFakeDio());
      expect(client.authenticated, false);
      expect(await client.status(), startsWith('1.9.64-r19'));
      await client.login('qa@example.invalid', 'clave-unicamente-qa');
      expect(client.authenticated, true);
      client.clearSession();
      expect(client.authenticated, false);
    },
  );

  test(
    'compara filtros planos R19 y mide price_asc sin tocar pedidos',
    () async {
      final client = MundicamQaClient(dio: qaFakeDio());
      await client.login('qa@example.invalid', 'clave-unicamente-qa');
      final result = await client.benchmark(144);
      expect(result.categoryId, 144);
      expect(result.sameFacets, true);
      expect(result.sameTotal, true);
      expect(result.skipsAggregates, true);
      expect(result.firstPageCount, 1);
      expect(result.validated, true);
    },
  );

  test('rechaza un PHP distinto de R19', () async {
    final client = MundicamQaClient(
      dio: qaFakeDio(version: '1.9.62-r17-warranties'),
    );
    await expectLater(client.status(), throwsFormatException);
  });
}
