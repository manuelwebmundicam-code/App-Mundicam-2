// ARCHIVO: lib/features/catalog/presentation/pages/producto_detalles_page.dart
// Sustituye el archivo completo por este contenido.

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mundicam/core/network/api_service.dart';
import 'package:mundicam/core/analytics/mundicam_analytics_service.dart';
import 'package:mundicam/features/cart/presentation/providers/cart_provider.dart';
import 'package:mundicam/features/catalog/data/models/producto.dart';
import 'package:mundicam/features/catalog/presentation/widgets/cross_sell_widgets.dart';
import 'package:mundicam/features/quotes/data/models/local_quote_model.dart';
import 'package:mundicam/features/quotes/presentation/providers/local_quote_provider.dart';
import 'package:mundicam/shared/theme/app_theme.dart';
import 'package:mundicam/shared/widgets/professional_page_app_bar.dart';


final _canViewStockDetailsProvider = FutureProvider<bool>((ref) async {
  try {
    // La sesión de negocio válida es WordPress/MundiCam App API.
    // No dependemos de Firebase para decidir permisos de stock.
    final canViewFromAppSession = await ApiService().currentSessionCanViewStockDetails();
    if (canViewFromAppSession) return true;

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return false;

    final wordpressId = await _resolveWordPressIdForCurrentUser(user);
    if (wordpressId == null || wordpressId <= 0) {
      return false;
    }

    return ApiService().canCustomerViewStockDetails(wordpressId);
  } catch (e) {
    if (kDebugMode) {
      debugPrint('Error resolviendo permiso de stock interno: $e');
    }
    return false;
  }
});

Future<int?> _resolveWordPressIdForCurrentUser(User user) async {
  final firestore = FirebaseFirestore.instance;

  try {
    final doc = await firestore.collection('users').doc(user.uid).get();
    final fromDoc = _wordPressIdFromUserData(doc.data());
    if (fromDoc != null && fromDoc > 0) {
      return fromDoc;
    }
  } catch (e) {
    if (kDebugMode) {
      debugPrint('No se pudo leer users/${user.uid}: $e');
    }
  }

  final email = user.email?.trim().toLowerCase();
  if (email != null && email.isNotEmpty) {
    try {
      final query = await firestore
          .collection('users')
          .where('email', isEqualTo: email)
          .limit(1)
          .get();

      if (query.docs.isNotEmpty) {
        final fromEmailDoc = _wordPressIdFromUserData(query.docs.first.data());
        if (fromEmailDoc != null && fromEmailDoc > 0) {
          return fromEmailDoc;
        }
      }
    } catch (e) {
      if (kDebugMode) {
        debugPrint('No se pudo buscar usuario por email para stock: $e');
      }
    }
  }

  return _wordPressIdFromDynamic(user.uid);
}

int? _wordPressIdFromUserData(Map<String, dynamic>? data) {
  if (data == null || data.isEmpty) return null;

  const keys = <String>[
    'wordpress_id',
    'wordpressId',
    'woocommerce_id',
    'woocommerceId',
    'customer_id',
    'customerId',
    'wp_user_id',
    'wpUserId',
    'woo_customer_id',
    'wooCustomerId',
    'uid',
  ];

  for (final key in keys) {
    final id = _wordPressIdFromDynamic(data[key]);
    if (id != null && id > 0) return id;
  }

  return null;
}

int? _wordPressIdFromDynamic(dynamic value) {
  if (value == null) return null;

  if (value is int && value > 0) return value;
  if (value is num && value > 0) return value.toInt();

  final raw = value.toString().trim();
  if (raw.isEmpty) return null;

  final direct = int.tryParse(raw);
  if (direct != null && direct > 0) return direct;

  final match = RegExp(r'wp[_-]?(\d+)', caseSensitive: false).firstMatch(raw);
  if (match != null) {
    final parsed = int.tryParse(match.group(1) ?? '');
    if (parsed != null && parsed > 0) return parsed;
  }

  return null;
}

class ProductDetailScreen extends ConsumerStatefulWidget {
  final Product product;
  final VoidCallback? onGoCart;
  final VoidCallback? onGoQuotes;
  final String? contextCategoryName;

  const ProductDetailScreen({
    super.key,
    required this.product,
    this.onGoCart,
    this.onGoQuotes,
    this.contextCategoryName,
  });

  @override
  ConsumerState<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends ConsumerState<ProductDetailScreen> {
  int _cantidad = 1;
  bool _isAddingToCart = false;
  bool _isAddingToQuote = false;
  bool _descriptionExpanded = true;
  bool _cargandoRecomendados = true;
  bool _isRefreshingProduct = false;
  Product? _productWithFreshStock;
  List<Product> _recomendados = [];

  static const Color _dark = Color(0xFF111827);
  static const Color _muted = Color(0xFF6B7280);
  static const Color _border = Color(0xFFE5E7EB);
  static const Color _softBg = Color(0xFFF8FAFC);

  @override
  void initState() {
    super.initState();
    _cargarStockDetalladoSiHaceFalta();
    _cargarRecomendados();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      MundicamAnalyticsService.instance.trackScreenViewForRoute(
        context,
        'product_detail',
      );
      unawaited(
        MundicamAnalyticsService.instance.track(
          eventName: 'product_view',
          objectType: 'product',
          objectId: widget.product.id,
          metadata: <String, dynamic>{
            if (widget.product.sku.trim().isNotEmpty)
              'sku': widget.product.sku.trim(),
          },
          dedupeKey: 'product_view:${widget.product.id}',
          dedupeWindow: const Duration(seconds: 2),
        ),
      );
    });
  }

  Future<void> _cargarStockDetalladoSiHaceFalta() async {
    if (widget.product.hasStockLocationDetails) return;

    try {
      final canViewStock = await ApiService().currentSessionCanViewStockDetails();
      if (!canViewStock) return;

      final fullProduct = await ApiService().getProductoById(widget.product.id);
      if (!mounted || fullProduct == null || !fullProduct.hasStockLocationDetails) {
        return;
      }

      setState(() {
        // Solo refrescamos stock y permisos comerciales. No tocamos el precio
        // recibido en el listado/búsqueda para evitar cambiar el rol efectivo.
        _productWithFreshStock = widget.product.copyWithStockFrom(fullProduct);
      });
    } catch (e) {
      if (kDebugMode) {
        debugPrint('No se pudo refrescar stock interno del producto: $e');
      }
    }
  }

  Future<void> _refreshProductDetail() async {
    if (_isRefreshingProduct) return;

    setState(() {
      _isRefreshingProduct = true;
    });

    try {
      final fullProduct = await ApiService().getProductoById(widget.product.id);
      if (!mounted) return;

      if (fullProduct != null) {
        setState(() {
          _productWithFreshStock = fullProduct;
        });
      }

      ref.invalidate(_canViewStockDetailsProvider);
      await _cargarRecomendados();
    } catch (e) {
      if (kDebugMode) {
        debugPrint('No se pudo recargar el producto: $e');
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('No se pudo actualizar el producto'),
            backgroundColor: AppColors.primary,
            behavior: SnackBarBehavior.floating,
            duration: Duration(seconds: 2),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isRefreshingProduct = false;
        });
      }
    }
  }

  Future<void> _cargarRecomendados() async {
    if (mounted) {
      setState(() => _cargandoRecomendados = true);
    }

    try {
      final api = ApiService();
      final product = widget.product;
      final brand = product.brandName?.trim() ?? '';
      final preferredCategoryIds = _preferredRelatedCategoryIds(product);

      // Buscamos solo en universos que tengan relación real con el producto.
      // No hacemos un fallback global de 50 productos porque era precisamente
      // lo que generaba recomendaciones sin sentido.
      final requests = <Future<List<Product>>>[];

      for (final categoryId in preferredCategoryIds) {
        requests.add(
          api.getProductos(
            categoryId: categoryId,
            perPage: 28,
          ),
        );
      }

      if (brand.isNotEmpty) {
        requests.add(
          api.getProductos(
            brand: brand,
            perPage: 28,
          ),
        );
      }

      if (requests.isEmpty) {
        if (!mounted) return;
        setState(() {
          _recomendados = <Product>[];
          _cargandoRecomendados = false;
        });
        return;
      }

      final groups = await Future.wait(requests);
      final candidatesById = <int, Product>{};

      for (final group in groups) {
        for (final candidate in group) {
          if (candidate.id <= 0 ||
              candidate.id == product.id ||
              !candidate.canAddToCart) {
            continue;
          }
          candidatesById[candidate.id] = candidate;
        }
      }

      final scored = candidatesById.values.map((candidate) {
        return MapEntry(
          candidate,
          _relatedProductScore(
            product,
            candidate,
            preferredCategoryIds.toSet(),
          ),
        );
      }).where((entry) {
        // Un candidato tiene que compartir una categoría útil o sumar
        // suficiente afinidad por marca + atributos + nombre.
        return entry.value >= 120;
      }).toList();

      scored.sort((a, b) {
        final byScore = b.value.compareTo(a.value);
        if (byScore != 0) return byScore;

        // A igualdad de afinidad damos prioridad a stock real.
        if (a.key.isInstock != b.key.isInstock) {
          return b.key.isInstock ? 1 : -1;
        }

        return a.key.name.compareTo(b.key.name);
      });

      final finalProducts =
          scored.map((entry) => entry.key).take(6).toList();

      if (!mounted) return;
      setState(() {
        _recomendados = finalProducts;
        _cargandoRecomendados = false;
      });
    } catch (error) {
      if (kDebugMode) {
        debugPrint('No se pudieron cargar relacionados coherentes: $error');
      }

      if (mounted) {
        setState(() {
          _recomendados = <Product>[];
          _cargandoRecomendados = false;
        });
      }
    }
  }

  List<int> _preferredRelatedCategoryIds(Product product) {
    if (product.categoryIds.isEmpty) return const <int>[];

    final indexes = List<int>.generate(product.categoryIds.length, (i) => i);

    indexes.sort((a, b) {
      final aName = a < product.categoryNames.length
          ? product.categoryNames[a]
          : '';
      final bName = b < product.categoryNames.length
          ? product.categoryNames[b]
          : '';

      final aGeneric = _isGenericRelatedCategory(aName);
      final bGeneric = _isGenericRelatedCategory(bName);

      if (aGeneric != bGeneric) {
        return aGeneric ? 1 : -1;
      }

      // Normalmente la categoría más específica tiene un nombre más
      // descriptivo que el padre general.
      return bName.trim().length.compareTo(aName.trim().length);
    });

    final ids = <int>[];
    for (final index in indexes) {
      final id = product.categoryIds[index];
      if (id <= 0 || ids.contains(id)) continue;

      final name = index < product.categoryNames.length
          ? product.categoryNames[index]
          : '';

      if (!_isGenericRelatedCategory(name) || ids.isEmpty) {
        ids.add(id);
      }

      if (ids.length >= 2) break;
    }

    if (ids.isEmpty) {
      for (final id in product.categoryIds) {
        if (id > 0 && !ids.contains(id)) {
          ids.add(id);
        }
        if (ids.length >= 2) break;
      }
    }

    return ids;
  }

  int _relatedProductScore(
    Product source,
    Product candidate,
    Set<int> preferredCategoryIds,
  ) {
    var score = 0;

    final sourceMeaningfulCategories = _meaningfulRelatedCategoryIds(source);
    final candidateCategories = candidate.categoryIds.toSet();
    final sharedMeaningfulCategories =
        sourceMeaningfulCategories.intersection(candidateCategories);

    score += sharedMeaningfulCategories.length * 170;

    if (sharedMeaningfulCategories
        .any((categoryId) => preferredCategoryIds.contains(categoryId))) {
      score += 70;
    }

    final sourceAllCategories = source.categoryIds.toSet();
    final sharedAnyCategories =
        sourceAllCategories.intersection(candidateCategories);

    if (sharedMeaningfulCategories.isEmpty && sharedAnyCategories.isNotEmpty) {
      score += 35;
    }

    final sourceBrand = _normalizeRelatedText(source.brandName ?? '');
    final candidateBrand = _normalizeRelatedText(candidate.brandName ?? '');
    final sameBrand = sourceBrand.isNotEmpty &&
        candidateBrand.isNotEmpty &&
        sourceBrand == candidateBrand;

    if (sameBrand) {
      score += 55;
    }

    final sharedAttributes = _sharedRelatedAttributes(source, candidate);
    score += sharedAttributes * 35;

    final sourceTokens = _relatedNameTokens(source.name);
    final candidateTokens = _relatedNameTokens(candidate.name);
    final sharedTokens = sourceTokens.intersection(candidateTokens).length;
    score += (sharedTokens > 4 ? 4 : sharedTokens) * 18;

    final contextCategory =
        _normalizeRelatedText(widget.contextCategoryName ?? '');
    if (contextCategory.isNotEmpty &&
        candidate.categoryNames.any((name) {
          final normalized = _normalizeRelatedText(name);
          return normalized == contextCategory ||
              normalized.contains(contextCategory) ||
              contextCategory.contains(normalized);
        })) {
      score += 40;
    }

    // El precio solo desempata. Nunca decide por sí solo una recomendación.
    final sourcePrice = _precioDouble(source);
    final candidatePrice = _precioDouble(candidate);
    if (sourcePrice > 0 && candidatePrice > 0) {
      final difference =
          (candidatePrice - sourcePrice).abs() / sourcePrice;

      if (difference <= 0.20) {
        score += 15;
      } else if (difference <= 0.45) {
        score += 8;
      }
    }

    return score;
  }

  Set<int> _meaningfulRelatedCategoryIds(Product product) {
    final result = <int>{};

    for (var i = 0; i < product.categoryIds.length; i++) {
      final id = product.categoryIds[i];
      if (id <= 0) continue;

      final name = i < product.categoryNames.length
          ? product.categoryNames[i]
          : '';

      // Si el API no trae nombre, conservamos el ID: no descartamos una
      // categoría real solo por falta de etiqueta.
      if (name.trim().isEmpty || !_isGenericRelatedCategory(name)) {
        result.add(id);
      }
    }

    return result.isNotEmpty ? result : product.categoryIds.toSet();
  }

  bool _isGenericRelatedCategory(String value) {
    final normalized = _normalizeRelatedText(value);

    const generic = <String>{
      '',
      'producto',
      'productos',
      'catalogo',
      'catalogo general',
      'todos',
      'destacados',
      'novedades',
      'ofertas',
      'marcas',
      'seguridad',
      'sin categoria',
      'uncategorized',
    };

    return generic.contains(normalized);
  }

  int _sharedRelatedAttributes(Product source, Product candidate) {
    final sourceMap = _relatedAttributeMap(source);
    final candidateMap = _relatedAttributeMap(candidate);

    var matches = 0;

    for (final entry in sourceMap.entries) {
      final candidateValues = candidateMap[entry.key];
      if (candidateValues == null || candidateValues.isEmpty) continue;

      if (entry.value.intersection(candidateValues).isNotEmpty) {
        matches++;
      }

      if (matches >= 4) break;
    }

    return matches;
  }

  Map<String, Set<String>> _relatedAttributeMap(Product product) {
    final result = <String, Set<String>>{};

    for (final attribute in product.attributes) {
      final name = _normalizeRelatedText(attribute.name);
      if (name.isEmpty ||
          name.contains('marca') ||
          name.contains('fabricante') ||
          name.contains('brand')) {
        continue;
      }

      final values = attribute.options
          .map(_normalizeRelatedText)
          .where((value) => value.isNotEmpty)
          .toSet();

      if (values.isNotEmpty) {
        result[name] = values;
      }
    }

    return result;
  }

  Set<String> _relatedNameTokens(String value) {
    const stopWords = <String>{
      'para',
      'con',
      'sin',
      'del',
      'las',
      'los',
      'una',
      'uno',
      'por',
      'the',
      'and',
      'full',
      'color',
      'pro',
      'camara',
      'camera',
      'sistema',
      'kit',
    };

    return _normalizeRelatedText(value)
        .split(RegExp(r'[^a-z0-9]+'))
        .where((token) =>
            token.length >= 3 &&
            !stopWords.contains(token) &&
            !RegExp(r'^\d+$').hasMatch(token))
        .toSet();
  }

  String _normalizeRelatedText(String value) {
    return value
        .trim()
        .toLowerCase()
        .replaceAll('á', 'a')
        .replaceAll('é', 'e')
        .replaceAll('í', 'i')
        .replaceAll('ó', 'o')
        .replaceAll('ú', 'u')
        .replaceAll('ü', 'u')
        .replaceAll('ñ', 'n')
        .replaceAll(RegExp(r'\s+'), ' ');
  }

  String _relatedReason(Product candidate) {
    final sourceMeaningful = _meaningfulRelatedCategoryIds(widget.product);

    for (var i = 0; i < candidate.categoryIds.length; i++) {
      final id = candidate.categoryIds[i];

      if (!sourceMeaningful.contains(id)) continue;

      if (i < candidate.categoryNames.length) {
        final name = candidate.categoryNames[i].trim();
        if (name.isNotEmpty && !_isGenericRelatedCategory(name)) {
          return name;
        }
      }
    }

    final sourceBrand = widget.product.brandName?.trim() ?? '';
    final candidateBrand = candidate.brandName?.trim() ?? '';

    if (sourceBrand.isNotEmpty &&
        candidateBrand.isNotEmpty &&
        _normalizeRelatedText(sourceBrand) ==
            _normalizeRelatedText(candidateBrand)) {
      return 'Misma marca · $candidateBrand';
    }

    return 'Selección relacionada';
  }

  String _limpiarHtml(String t) {
    // Conserva la estructura de tablas/listas antes de borrar HTML.
    // Si se eliminan las etiquetas de una tabla sin saltos de línea, la ficha
    // queda ilegible: ESPECIFICACIONESParámetroValorVoltaje...
    return t
        .replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n')
        .replaceAll(RegExp(r'</(p|div|section|article|h[1-6])\s*>', caseSensitive: false), '\n')
        .replaceAll(RegExp(r'<(p|div|section|article|h[1-6])[^>]*>', caseSensitive: false), '\n')
        .replaceAll(RegExp(r'<li[^>]*>', caseSensitive: false), '\n• ')
        .replaceAll(RegExp(r'</li\s*>', caseSensitive: false), '\n')
        .replaceAll(RegExp(r'<tr[^>]*>', caseSensitive: false), '\n')
        .replaceAll(RegExp(r'</tr\s*>', caseSensitive: false), '\n')
        .replaceAll(RegExp(r'<t[dh][^>]*>', caseSensitive: false), '\n')
        .replaceAll(RegExp(r'</t[dh]\s*>', caseSensitive: false), '\n')
        .replaceAll(RegExp(r'</?(table|thead|tbody|tfoot)[^>]*>', caseSensitive: false), '\n')
        .replaceAll(RegExp(r'<[^>]*>'), ' ')
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&amp;', '&')
        .replaceAll('&quot;', '"')
        .replaceAll('&#034;', '"')
        .replaceAll('&#039;', "'")
        .replaceAll('&apos;', "'")
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&#8211;', '-')
        .replaceAll('&ndash;', '-')
        .replaceAll('&mdash;', '-')
        .replaceAll(RegExp(r'[ \t\r\f\v]+'), ' ')
        .replaceAll(RegExp(r' *\n *'), '\n')
        .replaceAll(RegExp(r'\n{3,}'), '\n\n')
        .trim();
  }

  String _bestDetailImageUrl(Product p) {
    final original = p.imageUrl.trim();
    if (original.isEmpty || original.toLowerCase() == 'null') {
      return 'https://via.placeholder.com/1200x1200.png?text=MundiCam';
    }

    return _upgradeWordPressImageUrl(original);
  }

  String _fallbackDetailImageUrl(Product p) {
    final original = p.imageUrl.trim();
    if (original.isEmpty || original.toLowerCase() == 'null') {
      return 'https://via.placeholder.com/1200x1200.png?text=MundiCam';
    }
    return _decodeUrl(original);
  }

  String _decodeUrl(String value) {
    return value
        .trim()
        .replaceAll('&amp;', '&')
        .replaceAll('&#038;', '&')
        .replaceAll('&quot;', '"');
  }

  String _upgradeWordPressImageUrl(String value) {
    final clean = _decodeUrl(value);
    if (clean.isEmpty) return clean;

    final uriParts = clean.split('?');
    final base = uriParts.first;

    final upgraded = base.replaceFirst(
      RegExp(r'-\d+x\d+(?=\.[a-zA-Z0-9]+(?:\.[a-zA-Z0-9]+)?$)'),
      '',
    );

    return upgraded;
  }

  void _openImagePreview(Product p) {
    final fullImage = _bestDetailImageUrl(p);
    final fallbackImage = _fallbackDetailImageUrl(p);

    showDialog<void>(
      context: context,
      barrierColor: Colors.black.withOpacity(0.88),
      builder: (dialogContext) {
        return Dialog.fullscreen(
          backgroundColor: Colors.black,
          child: SafeArea(
            child: Stack(
              children: [
                Center(
                  child: InteractiveViewer(
                    minScale: 0.8,
                    maxScale: 4,
                    child: CachedNetworkImage(
                      imageUrl: fullImage,
                      fit: BoxFit.contain,
                      memCacheWidth: 1800,
                      maxWidthDiskCache: 2400,
                      placeholder: (context, url) => const Center(
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      ),
                      errorWidget: (context, url, error) => CachedNetworkImage(
                        imageUrl: fallbackImage,
                        fit: BoxFit.contain,
                        memCacheWidth: 1400,
                        maxWidthDiskCache: 1800,
                        errorWidget: (context, url, error) => const Icon(
                          Icons.broken_image_outlined,
                          color: Colors.white54,
                          size: 70,
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 12,
                  right: 12,
                  child: IconButton.filled(
                    style: IconButton.styleFrom(
                      backgroundColor: Colors.white.withOpacity(0.14),
                      foregroundColor: Colors.white,
                    ),
                    onPressed: () => Navigator.of(dialogContext).pop(),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  double _precioDouble(Product p) {
    return double.tryParse(p.price.replaceAll(',', '.').trim()) ?? 0;
  }

  double _precioRegularDouble(Product p) {
    return double.tryParse(p.regularPrice.replaceAll(',', '.').trim()) ?? 0;
  }

  String _formatearPrecio(double v) {
    if (v <= 0) return 'Bajo consulta';
    return '${v.toStringAsFixed(2).replaceAll('.', ',')} €';
  }


  int _safeQuantity(Product p) {
    if (!p.canAddToCart) return 0;
    final maxPurchaseQty = p.maxPurchaseQty;
    if (maxPurchaseQty <= 0) return _cantidad;
    return _cantidad.clamp(1, maxPurchaseQty).toInt();
  }

  int _safeQuoteQuantity(Product p) {
    final selectedQty = _cantidad < 1 ? 1 : _cantidad;
    final internalQty = p.generalStockQuantity + p.murciaStockQuantity;

    // En varios productos el PHP marca el producto como presupuestable/en stock,
    // pero los campos de stock interno General/Murcia llegan a 0. En ese caso
    // no debemos bloquear el presupuesto: usamos la cantidad elegida por el usuario.
    if (p.maxPurchaseQty > 0) {
      return selectedQty.clamp(1, p.maxPurchaseQty).toInt();
    }
    if (internalQty > 0) {
      return selectedQty.clamp(1, internalQty).toInt();
    }
    if (p.stockQuantity > 0) {
      return selectedQty.clamp(1, p.stockQuantity).toInt();
    }

    return selectedQty;
  }

  bool _canIncreaseQuantity(Product p) {
    if (!p.canAddToCart) {
      // Para presupuesto no limitamos por stock: se puede solicitar presupuesto
      // de productos agotados o pendientes de reposición.
      return p.canRequestQuote;
    }
    final maxPurchaseQty = p.maxPurchaseQty;
    return maxPurchaseQty <= 0 || _cantidad < maxPurchaseQty;
  }

  String? _resolveVisualCategory(Product p) {
    final fromContext = widget.contextCategoryName?.trim();
    if (fromContext != null && fromContext.isNotEmpty) return fromContext;
    final short = _limpiarHtml(p.shortDescription);
    if (short.isNotEmpty) {
      final firstLine = short.split('\n').map((e) => e.trim()).firstWhere(
            (e) => e.isNotEmpty,
        orElse: () => '',
      );
      if (firstLine.isNotEmpty && firstLine.length <= 40) return firstLine;
    }
    return null;
  }

  String _normalizeMultilineText(String text) {
    final expanded = _expandCollapsedTechnicalText(text);
    final lines = expanded
        .split('\n')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
    return lines.join('\n');
  }

  String _expandCollapsedTechnicalText(String text) {
    var out = text
        .replaceAll('\r', '\n')
        .replaceAll(RegExp(r'[ \t\f\v]+'), ' ')
        .replaceAll(RegExp(r' *\n *'), '\n')
        .replaceAll(RegExp(r'\n{3,}'), '\n\n')
        .trim();

    if (out.isEmpty) return out;

    out = out.replaceAllMapped(
      RegExp(r'(ESPECIFICACIONES\s+T[ÉE]CNICAS)\s*(Par[áa]metro)', caseSensitive: false),
          (m) => '${m.group(1)}\n${m.group(2)}',
    );
    out = out.replaceAllMapped(
      RegExp(r'(Par[áa]metro)\s*(Valor)', caseSensitive: false),
          (m) => '${m.group(1)}\n${m.group(2)}',
    );

    // Algunos productos llegan desde WooCommerce con la tabla técnica ya sin
    // etiquetas HTML y sin separadores. Insertamos saltos antes/después de los
    // campos técnicos habituales para recuperar formato de tabla.
    final technicalLabels = <String>[
      'Temperatura de funcionamiento',
      'Temperatura de almacenamiento',
      'Humedad de funcionamiento',
      'Humedad de almacenamiento',
      'Protección de sobrecarga',
      'Protección de sobretensión',
      'Corriente de interrupción',
      'Resistencia de aislamiento',
      'Rango de ajuste de voltaje',
      'Tolerancia de voltaje',
      'Corriente de entrada',
      'Corriente de salida',
      'Corriente residual',
      'Aislamiento (I/P-FG)',
      'Aislamiento (I/P–FG)',
      'Aislamiento (O/P-FG)',
      'Aislamiento (O/P–FG)',
      'Potencia nominal',
      'Tiempo de subida',
      'Carga de entrada',
      'Voltaje de salida',
      'Onda y ruido',
      'Certificaciones',
      'Dimensiones',
    ];

    for (final label in technicalLabels) {
      final escaped = RegExp.escape(label);
      out = out.replaceAllMapped(RegExp(escaped, caseSensitive: false), (match) {
        final found = match.group(0) ?? label;
        final before = match.start > 0 ? out.substring(match.start - 1, match.start) : '\n';
        final after = match.end < out.length ? out.substring(match.end, match.end + 1) : '\n';
        final prefix = before == '\n' ? '' : '\n';
        final suffix = after == '\n' ? '' : '\n';
        return '$prefix$found$suffix';
      });
    }

    out = out.replaceAllMapped(
      RegExp(r'([a-záéíóúñ0-9\)])\.([A-ZÁÉÍÓÚÑ])'),
          (m) => '${m.group(1)}.\n${m.group(2)}',
    );
    out = out.replaceAllMapped(
      RegExp(r'(Protecciones avanzadas:)\s*', caseSensitive: false),
          (m) => '\n${m.group(1)} ',
    );
    out = out.replaceAllMapped(
      RegExp(r'(Funcionamiento robusto:)\s*', caseSensitive: false),
          (m) => '\n${m.group(1)} ',
    );

    return out
        .replaceAll(RegExp(r' *\n *'), '\n')
        .replaceAll(RegExp(r'\n{3,}'), '\n\n')
        .trim();
  }

  bool _isTechnicalHeading(String value) {
    final clean = value
        .toLowerCase()
        .replaceAll(':', '')
        .replaceAll('á', 'a')
        .replaceAll('é', 'e')
        .replaceAll('í', 'i')
        .replaceAll('ó', 'o')
        .replaceAll('ú', 'u')
        .trim();

    return clean == 'especificaciones tecnicas' ||
        clean == 'ficha tecnica' ||
        clean == 'caracteristicas tecnicas' ||
        clean == 'parametro' ||
        clean == 'valor';
  }

  List<MapEntry<String, String>> _parseKeyValueRows(String text) {
    final normalized = _normalizeMultilineText(text);
    final lines = normalized
        .split('\n')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .where((e) => !_isTechnicalHeading(e))
        .toList();

    if (lines.length < 4) return <MapEntry<String, String>>[];

    final rows = <MapEntry<String, String>>[];
    for (var i = 0; i < lines.length - 1; i += 2) {
      final key = lines[i].trim().replaceAll(RegExp(r'[:\-–—]+$'), '').trim();
      final value = lines[i + 1].trim();
      if (key.isEmpty || value.isEmpty) continue;
      if (key.length > 58) return <MapEntry<String, String>>[];
      rows.add(MapEntry(key, value));
    }

    return rows.length >= 2 ? rows : <MapEntry<String, String>>[];
  }


  List<MapEntry<String, String>> _attributeRows(Product p) {
    final rows = <MapEntry<String, String>>[];

    for (final attr in p.attributes) {
      final name = attr.name.trim();
      final value = attr.options
          .map((e) => e.trim())
          .where((e) => e.isNotEmpty)
          .join(', ');

      if (name.isEmpty || value.isEmpty) continue;

      final normalized = name
          .toLowerCase()
          .replaceAll('pa_', '')
          .replaceAll('-', ' ')
          .replaceAll('_', ' ')
          .trim();

      if (normalized == 'marca' ||
          normalized == 'marcas' ||
          normalized == 'brand' ||
          normalized == 'fabricante') {
        continue;
      }

      rows.add(MapEntry(_prettyAttributeName(name), value));
    }

    return rows.take(14).toList();
  }

  String _prettyAttributeName(String value) {
    final clean = value
        .replaceAll('pa_', '')
        .replaceAll('-', ' ')
        .replaceAll('_', ' ')
        .trim();

    if (clean.isEmpty) return value;

    return clean
        .split(RegExp(r'\s+'))
        .map((word) {
      if (word.isEmpty) return word;
      if (word.length <= 3 && word == word.toUpperCase()) return word;
      return '${word[0].toUpperCase()}${word.substring(1).toLowerCase()}';
    })
        .join(' ');
  }

  List<String> _descriptionLines(String text) {
    final expanded = _expandCollapsedTechnicalText(text);
    final result = <String>[];

    for (final raw in expanded.split('\n')) {
      final line = raw.trim();
      if (line.isEmpty || _isTechnicalHeading(line)) continue;
      result.addAll(_splitReadableDescriptionLine(line));
    }

    return result.where((e) => e.trim().isNotEmpty).toList();
  }

  List<String> _splitReadableDescriptionLine(String line) {
    final clean = line.trim();
    if (clean.length <= 150 || clean.startsWith('•')) {
      return <String>[clean];
    }

    var working = clean
        .replaceAllMapped(
          RegExp(r'([a-záéíóúñ0-9\)])\.([A-ZÁÉÍÓÚÑ])'),
              (m) => '${m.group(1)}.\n${m.group(2)}',
        )
        .replaceAllMapped(
          RegExp(r'(Protecciones avanzadas:)\s*', caseSensitive: false),
              (m) => '\n${m.group(1)} ',
        )
        .replaceAllMapped(
          RegExp(r'(Funcionamiento robusto:)\s*', caseSensitive: false),
              (m) => '\n${m.group(1)} ',
        );

    final parts = working
        .split('\n')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();

    if (parts.length <= 1) return <String>[clean];
    return parts;
  }

  void _closeProductStackAndGo(VoidCallback callback) {
    final navigator = Navigator.of(context);
    if (navigator.canPop()) {
      navigator.popUntil((route) => route.isFirst);
    }
    WidgetsBinding.instance.addPostFrameCallback((_) {
      callback();
    });
  }

  void _goToQuotesKeepingTabs() {
    final goQuotes = widget.onGoQuotes;
    if (goQuotes != null) {
      _closeProductStackAndGo(goQuotes);
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Producto añadido al presupuesto'),
        backgroundColor: AppColors.primary,
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: 1),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = _productWithFreshStock ?? widget.product;
    final precio = _precioDouble(p);
    final precioRegular = _precioRegularDouble(p);
    // La app no muestra precios tachados. El backend debe devolver en price el
    // precio real del cliente/rol; regularPrice queda solo como referencia interna.
    const tieneDescuento = false;
    const descuento = 0;
    const ahorro = 0.0;
    final enStock = p.hasStock;
    final bajoConsulta = p.isUnderConsultation;
    final canViewStockDetails = ref.watch(_canViewStockDetailsProvider).maybeWhen(
      data: (value) => value,
      orElse: () => false,
    );
    final descCorta = _normalizeMultilineText(_limpiarHtml(p.shortDescription));
    final descLimpia = _normalizeMultilineText(_limpiarHtml(p.description));
    final descripcionCompletaRows = _parseKeyValueRows(descLimpia);
    final attributeRows = _attributeRows(p);
    final categoriaVisual = _resolveVisualCategory(p);

    String? marca;
    for (final a in p.attributes) {
      if (a.name.toLowerCase().contains('marca') && a.options.isNotEmpty) {
        marca = a.options.first;
        break;
      }
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF5F6F8),
      appBar: ProfessionalPageAppBar(
        title: categoriaVisual ?? 'DETALLE PRODUCTO',
        subtitle: '',
        icon: Icons.inventory_2_outlined,
        onBack: () => Navigator.pop(context),
      ),
      bottomNavigationBar: _bottomActions(p, enStock),
      body: RefreshIndicator(
        color: AppColors.primary,
        onRefresh: _refreshProductDetail,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(
            parent: BouncingScrollPhysics(),
          ),
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 22),
          children: [
            _imageCard(p),
            const SizedBox(height: 14),
            _productHeader(
              p: p,
              marca: marca,
              precio: precio,
              precioRegular: precioRegular,
              tieneDescuento: tieneDescuento,
              descuento: descuento,
              ahorro: ahorro,
              enStock: enStock,
              bajoConsulta: bajoConsulta,
              canViewStockDetails: canViewStockDetails,
            ),
            const SizedBox(height: 16),
            _trustBlock(),
            const SizedBox(height: 18),
            _buildSectionTitle('INFORMACIÓN TÉCNICA'),
            const SizedBox(height: 12),
            if (descCorta.isNotEmpty) ...[
              _buildShortDescriptionCard(
                descCorta,
                title: 'Características principales',
                icon: Icons.tune_rounded,
              ),
              const SizedBox(height: 12),
            ],
            if (attributeRows.isNotEmpty) ...[
              _buildAttributesCard(attributeRows),
              const SizedBox(height: 12),
            ],
            if (descLimpia.isNotEmpty &&
                descLimpia != 'Sin descripción detallada' &&
                descLimpia != descCorta) ...[
              if (descripcionCompletaRows.isNotEmpty)
                _buildExpandableKeyValueCard(
                  title: 'Ficha técnica detallada',
                  icon: Icons.table_chart_outlined,
                  rows: descripcionCompletaRows,
                )
              else
                _buildExpandableDescription(
                  title: 'Descripción técnica',
                  icon: Icons.article_outlined,
                  text: descLimpia,
                ),
              const SizedBox(height: 18),
            ],
            if (!_cargandoRecomendados && _recomendados.isNotEmpty) ...[
              _buildRecommendedSection(marca),
              const SizedBox(height: 20),
            ],
          ],
        ),
      ),
    );
  }

  Widget _imageCard(Product p) {
    final fullImage = _bestDetailImageUrl(p);
    final fallbackImage = _fallbackDetailImageUrl(p);
    final hasRealImage = p.imageUrl.trim().isNotEmpty &&
        !p.imageUrl.toLowerCase().contains('placeholder');

    return Container(
      width: double.infinity,
      height: 340,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.035),
            blurRadius: 16,
            offset: const Offset(0, 7),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: Hero(
              tag: 'prod_${p.id}',
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: hasRealImage ? () => _openImagePreview(p) : null,
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: CachedNetworkImage(
                      imageUrl: fullImage,
                      fit: BoxFit.contain,
                      alignment: Alignment.center,
                      memCacheWidth: 1800,
                      maxWidthDiskCache: 2400,
                      fadeInDuration: const Duration(milliseconds: 120),
                      placeholder: (context, url) => const Center(
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppColors.primary,
                        ),
                      ),
                      errorWidget: (context, url, error) {
                        if (fallbackImage != fullImage && fallbackImage.isNotEmpty) {
                          return CachedNetworkImage(
                            imageUrl: fallbackImage,
                            fit: BoxFit.contain,
                            memCacheWidth: 1200,
                            maxWidthDiskCache: 1800,
                            errorWidget: (context, url, error) => const Icon(
                              Icons.broken_image,
                              size: 60,
                              color: _border,
                            ),
                          );
                        }

                        return const Icon(
                          Icons.broken_image,
                          size: 60,
                          color: _border,
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),
          ),
          if (hasRealImage)
            Positioned(
              right: 10,
              bottom: 10,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.62),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.zoom_out_map_rounded,
                      color: Colors.white,
                      size: 15,
                    ),
                    SizedBox(width: 6),
                    Text(
                      'Ampliar',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _productHeader({
    required Product p,
    required String? marca,
    required double precio,
    required double precioRegular,
    required bool tieneDescuento,
    required int descuento,
    required double ahorro,
    required bool enStock,
    required bool bajoConsulta,
    required bool canViewStockDetails,
  }) {
    final marcaText = marca?.trim();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _stockBadge(enStock, bajoConsulta),
              if (marcaText != null && marcaText.isNotEmpty) ...[
                const SizedBox(width: 10),
                Expanded(
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: _brandTopLabel(marcaText),
                  ),
                ),
              ] else const Spacer(),
            ],
          ),
          if (canViewStockDetails) ...[
            const SizedBox(height: 10),
            _StockDetailsText(
              product: p,
              hasStock: enStock,
            ),
          ],
          if (p.sku.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(
              'REF: ${p.sku}',
              style: const TextStyle(
                fontSize: 12.5,
                color: _muted,
                fontWeight: FontWeight.w700,
                height: 1.35,
              ),
            ),
          ],
          const SizedBox(height: 12),
          Text(
            p.name,
            style: const TextStyle(
              fontSize: 23,
              fontWeight: FontWeight.w900,
              height: 1.12,
              color: _dark,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (tieneDescuento) ...[
                      Text(
                        _formatearPrecio(precioRegular),
                        style: const TextStyle(
                          fontSize: 14,
                          color: Color(0xFF9CA3AF),
                          decoration: TextDecoration.lineThrough,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 2),
                    ],
                    Align(
                      alignment: Alignment.centerLeft,
                      child: FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: Alignment.centerLeft,
                        child: Text(
                          _formatearPrecio(precio),
                          maxLines: 1,
                          softWrap: false,
                          style: TextStyle(
                            fontSize: precio > 0 ? 31 : 23,
                            fontWeight: FontWeight.w900,
                            color: AppColors.primary,
                            fontFamily: 'Oswald',
                            height: 1,
                          ),
                        ),
                      ),
                    ),
                    if (tieneDescuento) ...[
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 7,
                              vertical: 3,
                            ),
                            decoration: BoxDecoration(
                              color: AppColors.primary.withOpacity(0.10),
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              '-$descuento%',
                              style: const TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                color: AppColors.primary,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Flexible(
                            child: Text(
                              'Ahorras ${_formatearPrecio(ahorro)}',
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF047857),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              if (p.canAddToCart) _quantityControl(p),
            ],
          ),
        ],
      ),
    );
  }

  Widget _brandTopLabel(String marca) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(
          Icons.verified_outlined,
          size: 16,
          color: AppColors.primary,
        ),
        const SizedBox(width: 6),
        Flexible(
          child: RichText(
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            text: TextSpan(
              children: [
                const TextSpan(
                  text: 'Marca: ',
                  style: TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w700,
                    color: _muted,
                  ),
                ),
                TextSpan(
                  text: marca.toUpperCase(),
                  style: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w900,
                    color: _dark,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _stockBadge(bool enStock, bool bajoConsulta) {
    final bg = bajoConsulta
        ? const Color(0xFFFFF7ED)
        : enStock
        ? const Color(0xFFEAF7EE)
        : const Color(0xFFFDECEC);
    final fg = bajoConsulta
        ? const Color(0xFFC2410C)
        : enStock
        ? const Color(0xFF218047)
        : const Color(0xFFC62828);
    final label = bajoConsulta ? 'Bajo consulta' : enStock ? 'Disponible 24/48h' : 'Sin Existencias';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: fg.withOpacity(0.18)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: fg,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 7),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: fg,
            ),
          ),
        ],
      ),
    );
  }

  Widget _quantityControl(Product p) {
    return Container(
      height: 42,
      decoration: BoxDecoration(
        color: _softBg,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: _border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _qtyBtn(Icons.remove_rounded, _cantidad > 1, () {
            if (_cantidad > 1) {
              HapticFeedback.selectionClick();
              setState(() => _cantidad--);
            }
          }),
          SizedBox(
            width: 34,
            child: Text(
              '$_cantidad',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w900,
                color: _dark,
              ),
            ),
          ),
          _qtyBtn(Icons.add_rounded, _canIncreaseQuantity(p), () {
            if (_canIncreaseQuantity(p)) {
              HapticFeedback.selectionClick();
              setState(() => _cantidad++);
            }
          }),
        ],
      ),
    );
  }

  Widget _trustBlock() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _border),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _trustItem(Icons.local_shipping_outlined, 'Envío 24-48h'),
          _trustItem(Icons.verified_user_outlined, 'Garantía'),
          _trustItem(Icons.support_agent_rounded, 'Soporte técnico'),
          _trustItem(Icons.business_center_outlined, 'B2B'),
        ],
      ),
    );
  }

  Widget _bottomActions(Product p, bool enStock) {
    final canAddToCart = p.canAddToCart;
    final canAddToQuote = p.canRequestQuote;
    final bajoConsulta = p.isUnderConsultation;

    return SafeArea(
      minimum: const EdgeInsets.fromLTRB(14, 10, 14, 14),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 18,
              offset: const Offset(0, -4),
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: SizedBox(
                height: 48,
                child: ElevatedButton.icon(
                  onPressed: canAddToCart && !_isAddingToCart ? _addToCart : null,
                  icon: _isAddingToCart
                      ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Colors.white,
                    ),
                  )
                      : Icon(
                    canAddToCart ? Icons.shopping_cart_outlined : Icons.block,
                    size: 18,
                  ),
                  label: Text(
                    bajoConsulta
                        ? 'Bajo consulta'
                        : canAddToCart
                        ? 'Añadir carrito'
                        : 'Sin Existencias',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: canAddToCart ? AppColors.primary : Colors.grey.shade400,
                    disabledBackgroundColor: Colors.grey.shade300,
                    disabledForegroundColor: Colors.grey.shade600,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: SizedBox(
                height: 48,
                child: OutlinedButton.icon(
                  onPressed: canAddToQuote && !_isAddingToQuote ? () => _addToQuote(p) : null,
                  icon: _isAddingToQuote
                      ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                      : Icon(
                    canAddToQuote ? Icons.description_outlined : Icons.block,
                    size: 18,
                  ),
                  label: Text(
                    _isAddingToQuote
                        ? 'Añadiendo...'
                        : canAddToQuote
                        ? 'Presupuesto'
                        : 'No presupuestar',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: canAddToQuote ? AppColors.textPrimary : Colors.grey,
                    side: BorderSide(
                      color: canAddToQuote ? const Color(0xFFD9DEE7) : Colors.grey.shade300,
                      width: 1.2,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _addToCart() async {
    if (!widget.product.canAddToCart || _isAddingToCart) return;
    final qty = _safeQuantity(widget.product);
    if (qty <= 0) return;

    setState(() => _isAddingToCart = true);
    ref.read(cartProvider.notifier).addProduct(widget.product, qty);
    HapticFeedback.mediumImpact();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$qty x ${widget.product.name} añadido al carrito'),
        backgroundColor: AppColors.primary,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 1),
      ),
    );
    if (mounted) setState(() => _isAddingToCart = false);

    await showMundicamCrossSellSheet(
      context: context,
      ref: ref,
      sourceProduct: widget.product,
      onGoCart: widget.onGoCart,
    );
  }

  Widget _buildSectionTitle(String title) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 24,
          decoration: BoxDecoration(
            color: AppColors.primary,
            borderRadius: BorderRadius.circular(999),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              fontFamily: 'Oswald',
              fontSize: 22,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.4,
              color: _dark,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildShortDescriptionCard(
      String text, {
        required String title,
        required IconData icon,
      }) {
    final lines = _descriptionLines(text);
    if (lines.isEmpty) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: AppColors.primary, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 14.5,
                    color: _dark,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...List.generate(lines.length > 10 ? 10 : lines.length, (index) {
            final rawLine = lines[index];
            final line = rawLine.replaceFirst(RegExp(r'^[•\-–—]+\s*'), '').trim();

            return Padding(
              padding: EdgeInsets.only(
                bottom: index == lines.length - 1 ? 0 : 9,
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 7,
                    height: 7,
                    margin: const EdgeInsets.only(top: 7),
                    decoration: const BoxDecoration(
                      color: AppColors.primary,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      line,
                      style: const TextStyle(
                        fontSize: 13.8,
                        color: _dark,
                        height: 1.42,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildAttributesCard(List<MapEntry<String, String>> rows) {
    if (rows.isEmpty) return const SizedBox.shrink();

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _border),
      ),
      child: Column(
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 14, 16, 10),
            child: Row(
              children: [
                Icon(Icons.fact_check_outlined, color: AppColors.primary, size: 20),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Datos técnicos destacados',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 14.5,
                      color: _dark,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFFF8FAFC),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _border),
              ),
              child: Column(
                children: List.generate(rows.length, (index) {
                  final row = rows[index];
                  final isLast = index == rows.length - 1;

                  return Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                    decoration: BoxDecoration(
                      color: index.isEven ? Colors.white : const Color(0xFFF8FAFC),
                      borderRadius: BorderRadius.vertical(
                        top: index == 0 ? const Radius.circular(14) : Radius.zero,
                        bottom: isLast ? const Radius.circular(14) : Radius.zero,
                      ),
                      border: isLast
                          ? null
                          : const Border(
                        bottom: BorderSide(color: _border, width: 1),
                      ),
                    ),
                    child: IntrinsicHeight(
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          SizedBox(
                            width: 118,
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Text(
                                row.key,
                                style: const TextStyle(
                                  fontSize: 12.2,
                                  fontWeight: FontWeight.w900,
                                  color: Color(0xFF334155),
                                  height: 1.35,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Container(width: 1, color: _border),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Text(
                                row.value,
                                style: const TextStyle(
                                  fontSize: 12.8,
                                  fontWeight: FontWeight.w600,
                                  color: _dark,
                                  height: 1.35,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildExpandableKeyValueCard({
    required String title,
    required IconData icon,
    required List<MapEntry<String, String>> rows,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _border),
      ),
      child: Column(
        children: [
          InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: () => setState(() => _descriptionExpanded = !_descriptionExpanded),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(
                children: [
                  Icon(icon, color: AppColors.primary, size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      title,
                      style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 14,
                        color: _dark,
                      ),
                    ),
                  ),
                  AnimatedRotation(
                    duration: const Duration(milliseconds: 200),
                    turns: _descriptionExpanded ? 0.5 : 0,
                    child: const Icon(
                      Icons.keyboard_arrow_down_rounded,
                      color: _muted,
                    ),
                  ),
                ],
              ),
            ),
          ),
          AnimatedCrossFade(
            firstChild: const SizedBox.shrink(),
            secondChild: Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFF8FAFC),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _border),
                ),
                child: Column(
                  children: List.generate(rows.length, (index) {
                    final row = rows[index];
                    final isLast = index == rows.length - 1;
                    return Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 12,
                      ),
                      decoration: BoxDecoration(
                        color: index.isEven ? Colors.white : const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.vertical(
                          top: index == 0 ? const Radius.circular(14) : Radius.zero,
                          bottom: isLast ? const Radius.circular(14) : Radius.zero,
                        ),
                        border: isLast
                            ? null
                            : const Border(
                          bottom: BorderSide(color: _border, width: 1),
                        ),
                      ),
                      child: IntrinsicHeight(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            SizedBox(
                              width: 118,
                              child: Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  row.key,
                                  style: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w900,
                                    color: Color(0xFF334155),
                                    height: 1.35,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Container(width: 1, color: _border),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  row.value,
                                  style: const TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w600,
                                    color: _dark,
                                    height: 1.35,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
                ),
              ),
            ),
            crossFadeState: _descriptionExpanded
                ? CrossFadeState.showSecond
                : CrossFadeState.showFirst,
            duration: const Duration(milliseconds: 220),
            sizeCurve: Curves.easeOut,
          ),
        ],
      ),
    );
  }

  Widget _buildExpandableDescription({
    required String title,
    required IconData icon,
    required String text,
  }) {
    final lines = _descriptionLines(text);
    if (lines.isEmpty) return const SizedBox.shrink();

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _border),
      ),
      child: Column(
        children: [
          InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: () => setState(() => _descriptionExpanded = !_descriptionExpanded),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(
                children: [
                  Icon(icon, color: AppColors.primary, size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      title,
                      style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 14.5,
                        color: _dark,
                      ),
                    ),
                  ),
                  AnimatedRotation(
                    duration: const Duration(milliseconds: 200),
                    turns: _descriptionExpanded ? 0.5 : 0,
                    child: const Icon(
                      Icons.keyboard_arrow_down_rounded,
                      color: _muted,
                    ),
                  ),
                ],
              ),
            ),
          ),
          AnimatedCrossFade(
            firstChild: const SizedBox.shrink(),
            secondChild: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: List.generate(lines.length, (index) {
                  final line = lines[index];
                  final looksLikeBullet =
                      line.startsWith('•') ||
                          line.startsWith('-') ||
                          line.startsWith('–') ||
                          line.startsWith('—');

                  if (looksLikeBullet) {
                    final cleanLine = line
                        .replaceFirst(RegExp(r'^[•\-–—]+\s*'), '')
                        .trim();

                    return Padding(
                      padding: EdgeInsets.only(bottom: index == lines.length - 1 ? 0 : 8),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 5,
                            height: 5,
                            margin: const EdgeInsets.only(top: 8),
                            decoration: const BoxDecoration(
                              color: AppColors.primary,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              cleanLine,
                              style: const TextStyle(
                                fontSize: 13.5,
                                color: _dark,
                                height: 1.5,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  }

                  final isHeading = line.length <= 42 &&
                      !line.contains('.') &&
                      !line.contains(':') &&
                      index != lines.length - 1;

                  return Padding(
                    padding: EdgeInsets.only(bottom: index == lines.length - 1 ? 0 : 10),
                    child: Text(
                      line,
                      style: TextStyle(
                        fontSize: isHeading ? 14.2 : 13.5,
                        color: isHeading ? _dark : _muted,
                        height: isHeading ? 1.25 : 1.55,
                        fontWeight: isHeading ? FontWeight.w900 : FontWeight.w500,
                      ),
                    ),
                  );
                }),
              ),
            ),
            crossFadeState: _descriptionExpanded
                ? CrossFadeState.showSecond
                : CrossFadeState.showFirst,
            duration: const Duration(milliseconds: 220),
            sizeCurve: Curves.easeOut,
          ),
        ],
      ),
    );
  }

  Widget _recommendedBrandLogo(Product product) {
    final brand = product.brandName?.trim() ?? '';
    if (brand.isEmpty) {
      return const SizedBox(height: 30);
    }

    final assetPath = _recommendedBrandAssetPath(brand);
    if (assetPath == null || assetPath.isEmpty) {
      return SizedBox(
        height: 30,
        child: Align(
          alignment: Alignment.centerLeft,
          child: Text(
            brand.toUpperCase(),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w900,
              color: _dark,
            ),
          ),
        ),
      );
    }

    return SizedBox(
      height: 30,
      width: 104,
      child: Align(
        alignment: Alignment.centerLeft,
        child: Image.asset(
          assetPath,
          width: 96,
          height: 28,
          fit: BoxFit.contain,
          alignment: Alignment.centerLeft,
          filterQuality: FilterQuality.high,
          errorBuilder: (_, __, ___) => Text(
            brand.toUpperCase(),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w900,
              color: _dark,
            ),
          ),
        ),
      ),
    );
  }

  String _recommendedBrandKey(String value) {
    return value
        .toLowerCase()
        .trim()
        .replaceAll('á', 'a')
        .replaceAll('à', 'a')
        .replaceAll('ä', 'a')
        .replaceAll('â', 'a')
        .replaceAll('é', 'e')
        .replaceAll('è', 'e')
        .replaceAll('ë', 'e')
        .replaceAll('ê', 'e')
        .replaceAll('í', 'i')
        .replaceAll('ì', 'i')
        .replaceAll('ï', 'i')
        .replaceAll('î', 'i')
        .replaceAll('ó', 'o')
        .replaceAll('ò', 'o')
        .replaceAll('ö', 'o')
        .replaceAll('ô', 'o')
        .replaceAll('ú', 'u')
        .replaceAll('ù', 'u')
        .replaceAll('ü', 'u')
        .replaceAll('û', 'u')
        .replaceAll('ñ', 'n')
        .replaceAll(RegExp(r'[^a-z0-9]+'), '');
  }

  String _recommendedCanonicalBrandKey(String value) {
    final key = _recommendedBrandKey(value);

    if (key.contains('hiwatch')) return 'hiwatch';
    if (key == 'hickvision') return 'hikvision';
    if (key == 'ajaxsystem') return 'ajax';
    if (key == 'tplinksystems') return 'tplink';
    if (key == 'dmtechsecurity') return 'dmtech';
    if (key == 'centuryc') return 'century';
    if (key == 'visionic') return 'visonic';
    if (key == 'secury360') return 'security360';
    if (key == 'zkteko') return 'zkteco';
    if (key == 'mci') return 'mci';
    if (key == 'mcipro') return 'mcipro';
    if (key == 'evolveextended' ||
        key == 'evolve' ||
        key == 'evolvextender' ||
        key == 'evolvextendermobilesecuritybox') {
      return 'evolve';
    }
    if (key == 'assaabloy' || key == 'tesaassaabloy') {
      return 'tesaassaabloy';
    }
    if (key == 'uniview') return 'unv';
    return key;
  }

  String? _recommendedBrandAssetPath(String brandName) {
    final key = _recommendedCanonicalBrandKey(brandName);

    const exact = <String, String>{
      'ajax': 'assets/brands/Ajax_system.png',
      'anviz': 'assets/brands/Anviz.png',
      'aiscan': 'assets/brands/AISCAN.png',
      'amc': 'assets/brands/AMC.png',
      'assaabloy': 'assets/brands/Tesa-assa-abloy.webp',
      'tesaassaabloy': 'assets/brands/Tesa-assa-abloy.webp',
      'bewave': 'assets/brands/BEWAVE.png',
      'byfog': 'assets/brands/BYFOG.png',
      'century': 'assets/brands/CENTURY.png',
      'dahua': 'assets/brands/Dahua.png',
      'defendertech': 'assets/brands/defendertech.png',
      'dji': 'assets/brands/DJI.png',
      'dmtech': 'assets/brands/DMTECH.png',
      'evolve': 'assets/brands/Evolve.png',
      'evolveextended': 'assets/brands/Evolve.png',
      'evolvextender': 'assets/brands/Evolve.png',
      'ezviz': 'assets/brands/Ezviz.png',
      'hectronica': 'assets/brands/HECTRONICA.png',
      'hikvision': 'assets/brands/HIKVISION.png',
      'hiwatch': 'assets/brands/HIWATCH.png',
      'hysoon': 'assets/brands/HYSOON.png',
      'imou': 'assets/brands/IMOU.png',
      'ipcom': 'assets/brands/IPCOM.png',
      'jadebird': 'assets/brands/Jade-bird.webp',
      'johnsoncontrols': 'assets/brands/Johnson-Controls.png',
      'ksenia': 'assets/brands/Ksenia.png',
      'llenari': 'assets/brands/LLenari.png',
      'mci': 'assets/brands/MCI.png',
      'mcipro': 'assets/brands/MCI_pro.png',
      'mobotix': 'assets/brands/MOBOTIX.png',
      'optex': 'assets/brands/optex.png',
      'paradox': 'assets/brands/Paradox.png',
      'powersafe': 'assets/brands/POWER-SAFE.png',
      'pyronix': 'assets/brands/pyronix.png',
      'qolsys': 'assets/brands/Qolsys.png',
      'rbtec': 'assets/brands/rbtec.png',
      'satel': 'assets/brands/Satel.png',
      'seagate': 'assets/brands/seagate.png',
      'security360': 'assets/brands/SECURITY360.png',
      'secury360': 'assets/brands/SECURITY360.png',
      'softguard': 'assets/brands/SoftGuard.png',
      'teletek': 'assets/brands/TELETEK.png',
      'tenda': 'assets/brands/Tenda.png',
      'toa': 'assets/brands/TOA.png',
      'tplink': 'assets/brands/TPLINK.png',
      'trikdis': 'assets/brands/trikdis.png',
      'tvt': 'assets/brands/TVT.png',
      'ubiquiti': 'assets/brands/Ubiquiti.png',
      'uniarch': 'assets/brands/Uniarch.png',
      'unv': 'assets/brands/UNV.png',
      'urfog': 'assets/brands/Ur-Fog.png',
      'vaelsys': 'assets/brands/vaelsys.png',
      'videofied': 'assets/brands/videofied.png',
      'visionaprotect': 'assets/brands/VISIONA_PROTECT.png',
      'visonic': 'assets/brands/Visionic.png',
      'westerndigital': 'assets/brands/western-digital.png',
      'wisim': 'assets/brands/WISIM.png',
      'yale': 'assets/brands/Yale.png',
      'zkteco': 'assets/brands/Zkteco.png',
      'zte': 'assets/brands/zte.png',
    };

    if (exact.containsKey(key)) return exact[key];

    for (final entry in exact.entries) {
      if (key.contains(entry.key) || entry.key.contains(key)) {
        return entry.value;
      }
    }

    return null;
  }

  Widget _recommendedStockChip(Product product) {
    final bajoConsulta = product.isUnderConsultation;
    final tieneStock = product.hasStock;
    final bgColor = bajoConsulta
        ? const Color(0xFFFFF7ED)
        : tieneStock
            ? const Color(0xFFEAF7EE)
            : const Color(0xFFFDECEC);
    final textColor = bajoConsulta
        ? const Color(0xFFC2410C)
        : tieneStock
            ? const Color(0xFF218047)
            : const Color(0xFFC62828);
    final label = bajoConsulta
        ? 'Bajo consulta'
        : tieneStock
            ? 'Disponible'
            : 'Sin existencias';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: textColor.withOpacity(0.18)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 5,
            height: 5,
            decoration: BoxDecoration(
              color: textColor,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 4),
          Text(
            label,
            maxLines: 1,
            style: TextStyle(
              fontSize: 9.3,
              color: textColor,
              fontWeight: FontWeight.w800,
              height: 1,
            ),
          ),
        ],
      ),
    );
  }

  Widget _recommendedShippingChip() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F9FB),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFFD9DEE7)),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.local_shipping_outlined,
            size: 11,
            color: _dark,
          ),
          SizedBox(width: 4),
          Text(
            'Envío 24-48h',
            style: TextStyle(
              fontSize: 9.1,
              color: _dark,
              fontWeight: FontWeight.w800,
              height: 1,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecommendedSection(String? marca) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: 4,
              height: 22,
              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(999),
              ),
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: Text(
                'Productos relacionados',
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 16,
                  color: _dark,
                ),
              ),
            ),
            Text(
              '${_recomendados.length} recomendados',
              style: const TextStyle(
                fontSize: 10.5,
                fontWeight: FontWeight.w700,
                color: _muted,
              ),
            ),
          ],
        ),
        const SizedBox(height: 5),
        const Padding(
          padding: EdgeInsets.only(left: 14),
          child: Text(
            'Seleccionados por categoría, marca y características',
            style: TextStyle(
              fontSize: 11.5,
              height: 1.25,
              color: _muted,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 360,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.only(bottom: 2),
            itemCount: _recomendados.length,
            separatorBuilder: (context, index) => const SizedBox(width: 12),
            itemBuilder: (context, i) {
              final product = _recomendados[i];
              final price = _precioDouble(product);

              return SizedBox(
                width: 204,
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(18),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ProductDetailScreen(
                            product: product,
                            onGoCart: widget.onGoCart,
                            onGoQuotes: widget.onGoQuotes,
                            contextCategoryName: widget.contextCategoryName,
                          ),
                        ),
                      );
                    },
                    child: Container(
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: _border),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0x0D111827),
                            blurRadius: 10,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            height: 112,
                            width: double.infinity,
                            color: Colors.white,
                            padding: const EdgeInsets.all(10),
                            child: CachedNetworkImage(
                              imageUrl: product.imageUrl,
                              fit: BoxFit.contain,
                              memCacheWidth: 520,
                              maxWidthDiskCache: 900,
                              fadeInDuration: const Duration(milliseconds: 120),
                              placeholder: (context, url) => Center(
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: AppColors.primary.withOpacity(0.25),
                                ),
                              ),
                              errorWidget: (context, url, error) => const Center(
                                child: Icon(
                                  Icons.image_not_supported_outlined,
                                  size: 34,
                                  color: _muted,
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(11, 8, 11, 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _recommendedBrandLogo(product),
                                  const SizedBox(height: 5),
                                  Text(
                                    product.name,
                                    maxLines: 3,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      fontSize: 12.4,
                                      height: 1.16,
                                      fontWeight: FontWeight.w900,
                                      color: _dark,
                                    ),
                                  ),
                                  if (product.sku.trim().isNotEmpty) ...[
                                    const SizedBox(height: 4),
                                    Text(
                                      'REF: ${product.sku.trim()}',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        fontSize: 9.4,
                                        color: _muted,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ],
                                  const Spacer(),
                                  Align(
                                    alignment: Alignment.centerLeft,
                                    child: FittedBox(
                                      fit: BoxFit.scaleDown,
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        _formatearPrecio(price),
                                        maxLines: 1,
                                        softWrap: false,
                                        style: TextStyle(
                                          fontSize: price > 0 ? 22 : 16,
                                          fontWeight: FontWeight.w900,
                                          color: AppColors.primary,
                                          fontFamily: 'Oswald',
                                          height: 1,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Wrap(
                                    spacing: 5,
                                    runSpacing: 5,
                                    children: [
                                      _recommendedStockChip(product),
                                      if (product.hasStock &&
                                          !product.isUnderConsultation)
                                        _recommendedShippingChip(),
                                    ],
                                  ),
                                  const SizedBox(height: 9),
                                  SizedBox(
                                    width: double.infinity,
                                    height: 36,
                                    child: ElevatedButton.icon(
                                      onPressed: product.canAddToCart
                                          ? () async {
                                              ref
                                                  .read(cartProvider.notifier)
                                                  .addProduct(product, 1);
                                              HapticFeedback.mediumImpact();

                                              ScaffoldMessenger.of(context)
                                                  .showSnackBar(
                                                SnackBar(
                                                  content: Text(
                                                    '${product.name} añadido',
                                                  ),
                                                  backgroundColor:
                                                      AppColors.primary,
                                                  behavior:
                                                      SnackBarBehavior.floating,
                                                  duration: const Duration(
                                                    seconds: 1,
                                                  ),
                                                ),
                                              );

                                              await showMundicamCrossSellSheet(
                                                context: context,
                                                ref: ref,
                                                sourceProduct: product,
                                                onGoCart: widget.onGoCart,
                                              );
                                            }
                                          : null,
                                      icon: Icon(
                                        product.canAddToCart
                                            ? Icons.shopping_cart_outlined
                                            : Icons.block_rounded,
                                        size: 15,
                                        color: Colors.white,
                                      ),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: product.canAddToCart
                                            ? AppColors.primary
                                            : Colors.grey.shade300,
                                        foregroundColor: Colors.white,
                                        elevation: 0,
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 8,
                                        ),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                        disabledBackgroundColor:
                                            Colors.grey.shade300,
                                      ),
                                      label: Text(
                                        product.canAddToCart
                                            ? 'AÑADIR CARRITO'
                                            : (product.isUnderConsultation
                                                ? 'BAJO CONSULTA'
                                                : 'SIN EXISTENCIAS'),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontSize: 10.5,
                                          fontWeight: FontWeight.w900,
                                          fontFamily: 'Oswald',
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _trustItem(IconData icon, String label) {
    return Column(
      children: [
        Icon(icon, size: 20, color: _dark),
        const SizedBox(height: 6),
        Text(
          label,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w700,
            color: _dark,
            height: 1.2,
          ),
        ),
      ],
    );
  }

  Widget _qtyBtn(IconData icon, bool enabled, VoidCallback onTap) {
    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: enabled ? onTap : null,
      child: SizedBox(
        width: 36,
        height: 40,
        child: Icon(
          icon,
          size: 18,
          color: enabled ? _dark : const Color(0xFF9CA3AF),
        ),
      ),
    );
  }

  Future<void> _addToQuote(Product product) async {
    if (_isAddingToQuote) return;

    final prod = _productWithFreshStock ?? product;
    if (prod.id == 0) {
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No se pudo identificar el producto para presupuesto.'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    if (!prod.canRequestQuote) {
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('No se puede añadir "${prod.name}" al presupuesto.'),
          backgroundColor: Colors.orange.shade700,
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 2),
        ),
      );
      return;
    }

    final calculatedQty = _safeQuoteQuantity(prod);
    final qty = calculatedQty > 0 ? calculatedQty : 1;

    setState(() => _isAddingToQuote = true);
    HapticFeedback.selectionClick();

    try {
      final notifier = ref.read(localQuotesProvider.notifier);
      final activeQuotes = ref
          .read(localQuotesProvider)
          .where((quote) => !quote.isExpired)
          .toList();

      final LocalQuote quote;
      if (activeQuotes.isNotEmpty) {
        quote = activeQuotes.first;
      } else {
        final orderId = DateTime.now().millisecondsSinceEpoch.toString();
        quote = await notifier.crearPresupuesto(
          orderId: orderId,
          nombre: 'Presupuesto #$orderId',
        );
      }

      await notifier.anadirItem(
        orderId: quote.orderId,
        item: LocalQuoteItem(
          productId: prod.id,
          productName: prod.name,
          quantity: qty,
          price: _precioDouble(prod),
        ),
      );

      if (!mounted) return;
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('$qty x ${prod.name} añadido al presupuesto'),
          backgroundColor: Colors.green.shade700,
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 2),
          action: SnackBarAction(
            label: 'VER',
            textColor: Colors.white,
            onPressed: _goToQuotesKeepingTabs,
          ),
        ),
      );
    } catch (e) {
      debugPrint('❌ Error en _addToQuote: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).clearSnackBars();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error añadiendo al presupuesto: $e'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isAddingToQuote = false);
    }
  }

}

class _StockDetailsText extends StatelessWidget {
  final Product product;
  final bool hasStock;

  const _StockDetailsText({
    required this.product,
    required this.hasStock,
  });

  @override
  Widget build(BuildContext context) {
    final cleanDetails = product.stockDetailsText?.trim();
    if (cleanDetails == null || cleanDetails.isEmpty) {
      return const SizedBox.shrink();
    }

    const textColor = Color(0xFF1565C0);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F9FB),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE1E4EA)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.inventory_2_outlined,
            size: 15,
            color: textColor,
          ),
          const SizedBox(width: 7),
          Expanded(
            child: Text(
              'Stock: $cleanDetails',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 11.5,
                color: textColor,
                fontWeight: FontWeight.w900,
                height: 1.25,
              ),
            ),
          ),
        ],
      ),
    );
  }
}


