import 'package:dio/dio.dart';

/// Catálogo público indexado del VPS. Metadatos, nunca precios ni stock.
/// No sustituye el API comercial autenticado de WooCommerce.
class VpsCatalogService {
  VpsCatalogService({Dio? dio})
    : _dio =
          dio ??
          Dio(
            BaseOptions(
              baseUrl: endpoint,
              connectTimeout: const Duration(milliseconds: 1500),
              receiveTimeout: const Duration(milliseconds: 2000),
              headers: const {'Accept': 'application/json'},
            ),
          );

  static const String endpoint = String.fromEnvironment(
    'MUNDICAM_FAST_SKU_URL',
    defaultValue: 'https://app.mundicam.com/app-fast/v1',
  );

  final Dio _dio;

  Future<List<Map<String, dynamic>>> brands() => _terms('/catalog/brands');

  /// Solo términos XStore con relaciones publicadas verificadas por ID.
  /// No sustituye /brands de la API comercial, que puede usar más taxonomías.
  Future<List<Map<String, dynamic>>> verifiedWordPressBrands() async {
    final terms = await _terms(
      '/catalog/brands',
      queryParameters: const {'source': 'wp'},
    );
    // Nunca confundir IDs XStore con otra taxonomía por coincidencia de nombre.
    if (terms.any(
      (term) =>
          term['source'] != 'wp_rest_verified' ||
          term['taxonomy'] != 'brand' ||
          term['vps_filter'] != 'xstore_brand',
    )) {
      return const [];
    }
    return terms;
  }

  /// Los 50 fabricantes reales verificados en el escaparate, con IDs XStore.
  /// No sustituye los filtros de la API autenticada, que pueden ser distintos.
  Future<List<Map<String, dynamic>>> verifiedCompleteBrands() async {
    final terms = await _terms(
      '/catalog/brands',
      queryParameters: const {'source': 'complete'},
    );
    final ids = <int>{};
    if (terms.any(
      (term) =>
          term['source'] != 'verified_storefront' ||
          term['taxonomy'] != 'brand' ||
          term['vps_filter'] != 'xstore_brand' ||
          !ids.add(term['id'] as int),
    )) {
      return const [];
    }
    return terms;
  }

  Future<List<Map<String, dynamic>>> categories() =>
      _terms('/catalog/categories');

  Future<List<Map<String, dynamic>>> _terms(
    String path, {
    Map<String, dynamic>? queryParameters,
  }) async {
    try {
      final response = await _dio.get<Map<String, dynamic>>(
        path,
        queryParameters: queryParameters,
      );
      final data = response.data;
      if (response.statusCode != 200 ||
          data?['scope'] != 'public_metadata_only' ||
          data?['results'] is! List) {
        return const [];
      }
      final result = <Map<String, dynamic>>[];
      for (final value in data!['results'] as List) {
        if (value is! Map ||
            value['id'] is! int ||
            value['id'] <= 0 ||
            value['name'] is! String ||
            value['slug'] is! String ||
            value['indexed_product_count'] is! int) {
          return const [];
        }
        result.add(Map<String, dynamic>.from(value));
      }
      return result;
    } on DioException {
      return const [];
    } on FormatException {
      return const [];
    } on TypeError {
      return const [];
    }
  }

  Future<Map<String, dynamic>?> productPage({
    required String taxonomy,
    required int id,
    int page = 1,
    int limit = 12,
    bool includeChildren = false,
  }) async {
    if (includeChildren && taxonomy != 'category') return null;
    if (!const [
          'brand',
          'category',
          'xstore_brand',
          'wp_product_brand',
        ].contains(taxonomy) ||
        id <= 0 ||
        page < 1 ||
        page > 1000 ||
        limit < 1 ||
        limit > 30) {
      return null;
    }
    try {
      final response = await _dio.get<Map<String, dynamic>>(
        '/catalog/products',
        queryParameters: {
          'taxonomy': taxonomy,
          'id': id,
          'page': page,
          'limit': limit,
          if (includeChildren) 'children': '1',
        },
      );
      final data = response.data;
      if (response.statusCode != 200 ||
          data?['scope'] != 'public_metadata_only' ||
          data?['requires_authenticated_hydration'] != true ||
          data?['results'] is! List ||
          data?['total'] is! int) {
        return null;
      }
      for (final row in data!['results'] as List) {
        if (row is! Map ||
            row['id'] is! int ||
            row['id'] <= 0 ||
            row['sku'] is! String ||
            row['name'] is! String ||
            row['image_url'] is! String) {
          return null;
        }
      }
      return {
        'results': (data!['results'] as List)
            .map(
              (row) => <String, dynamic>{
                'id': row['id'],
                'sku': row['sku'],
                'name': row['name'],
                'image_url': row['image_url'],
              },
            )
            .toList(),
        'total': data['total'],
        'page': page,
        'per_page': limit,
      };
    } on DioException {
      return null;
    } on FormatException {
      return null;
    } on TypeError {
      return null;
    }
  }
}
